# LieuRealisationOffre - Modèle des Objets de Santé (MOS) v0.1.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **LieuRealisationOffre**

## Logical Model: LieuRealisationOffre 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/mos/StructureDefinition/LieuRealisationOffre | *Version*:0.1.0-ballot |
| Draft as of 2026-07-27 | *Computable Name*:LieuRealisationOffre |

 
Espace disposant d’un ensemble de ressources pour réaliser une offre. Lorsque les ressources qui contribuent à l’offre sont mobiles, le lieu de réalisation de l’offre correspond au lieu administratif où est organisée la prise en charge. 

**Utilisations:**

* Utilise ce/t/te Modèle logique: [CapaciteHabitation](StructureDefinition-CapaciteHabitation.md), [CapacitePriseCharge](StructureDefinition-CapacitePriseCharge.md), [EquipementSpecifique](StructureDefinition-EquipementSpecifique.md), [Lieu](StructureDefinition-Lieu.md) and [OffreOperationnelle](StructureDefinition-OffreOperationnelle.md)

Vous pouvez également vérifier [les usages dans le FHIR IG Statistics](https://packages2.fhir.org/xig/ans.fr.mos|current/StructureDefinition/LieuRealisationOffre)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-LieuRealisationOffre.csv), [Excel](StructureDefinition-LieuRealisationOffre.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "LieuRealisationOffre",
  "url" : "https://interop.esante.gouv.fr/ig/mos/StructureDefinition/LieuRealisationOffre",
  "version" : "0.1.0-ballot",
  "name" : "LieuRealisationOffre",
  "title" : "LieuRealisationOffre",
  "status" : "draft",
  "date" : "2026-07-27T09:56:46+00:00",
  "publisher" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
  "contact" : [{
    "name" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
    "telecom" : [{
      "system" : "url",
      "value" : "https://esante.gouv.fr"
    }]
  }],
  "description" : "Espace disposant d'un ensemble de ressources pour réaliser une offre. Lorsque les ressources qui contribuent à l'offre sont mobiles, le lieu de réalisation de l'offre correspond au lieu administratif où est organisée la prise en charge.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://interop.esante.gouv.fr/ig/mos/StructureDefinition/LieuRealisationOffre",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "LieuRealisationOffre",
      "path" : "LieuRealisationOffre",
      "short" : "Espace disposant d'un ensemble de ressources pour réaliser une offre. Lorsque les ressources qui contribuent à l'offre sont mobiles, le lieu de réalisation de l'offre correspond au lieu administratif où est organisée la prise en charge.",
      "definition" : "Espace disposant d'un ensemble de ressources pour réaliser une offre. Lorsque les ressources qui contribuent à l'offre sont mobiles, le lieu de réalisation de l'offre correspond au lieu administratif où est organisée la prise en charge."
    },
    {
      "id" : "LieuRealisationOffre.idExterneSynchro",
      "path" : "LieuRealisationOffre.idExterneSynchro",
      "short" : "L’identifiant externe de synchronisation est l’identifiant défini par le porteur d’offre pour la zone d’hébergement des lits.",
      "definition" : "L’identifiant externe de synchronisation est l’identifiant défini par le porteur d’offre pour la zone d’hébergement des lits.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier"
      }]
    },
    {
      "id" : "LieuRealisationOffre.nomExterneSynchro",
      "path" : "LieuRealisationOffre.nomExterneSynchro",
      "short" : "Nom de la zone d’hébergement des lits.",
      "definition" : "Nom de la zone d’hébergement des lits.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "LieuRealisationOffre.OffreOperationnelle",
      "path" : "LieuRealisationOffre.OffreOperationnelle",
      "short" : "Lien vers la classe OffreOperationnelle",
      "definition" : "Lien vers la classe OffreOperationnelle",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "https://interop.esante.gouv.fr/ig/mos/StructureDefinition/OffreOperationnelle"
      }]
    },
    {
      "id" : "LieuRealisationOffre.CapacitePriseCharge",
      "path" : "LieuRealisationOffre.CapacitePriseCharge",
      "short" : "Lien vers la classe CapacitePriseCharge",
      "definition" : "Lien vers la classe CapacitePriseCharge",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "https://interop.esante.gouv.fr/ig/mos/StructureDefinition/CapacitePriseCharge"
      }]
    },
    {
      "id" : "LieuRealisationOffre.Lieu",
      "path" : "LieuRealisationOffre.Lieu",
      "short" : "Lien vers la classe Lieu",
      "definition" : "Lien vers la classe Lieu",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "https://interop.esante.gouv.fr/ig/mos/StructureDefinition/Lieu"
      }]
    },
    {
      "id" : "LieuRealisationOffre.EquipementSpecifique",
      "path" : "LieuRealisationOffre.EquipementSpecifique",
      "short" : "Lien vers la classe EquipementSpecifique",
      "definition" : "Lien vers la classe EquipementSpecifique",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "https://interop.esante.gouv.fr/ig/mos/StructureDefinition/EquipementSpecifique"
      }]
    },
    {
      "id" : "LieuRealisationOffre.CapaciteHabitation",
      "path" : "LieuRealisationOffre.CapaciteHabitation",
      "short" : "Lien vers la classe CapaciteHabitation",
      "definition" : "Lien vers la classe CapaciteHabitation",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "https://interop.esante.gouv.fr/ig/mos/StructureDefinition/CapaciteHabitation"
      }]
    }]
  }
}

```
